function map = createMap(T)
    map = cat(2,T',T',T');
end

