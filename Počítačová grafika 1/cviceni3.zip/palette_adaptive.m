function map = palette_adaptive(img)
%PALETTE_ADAPTIVE Summary of this function goes here
%   Detailed explanation goes here

% pomer rezu
cut_r = 3.2;
cut_g = 1.7;
cut_b = 10;



end

