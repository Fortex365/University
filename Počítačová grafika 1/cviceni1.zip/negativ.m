function I2 = negativ(I)
%NEGATIV Summary of this function goes here
%   Detailed explanation goes here

    I2 = 255 - I;

end

