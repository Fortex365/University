function I_cmy = rgb2cmy(I_rgb)
    I_cmy = 255 - I_rgb;
end

