function I_rgb = cmy2rgb(I_cmy)
    I_rgb = 255 - I_cmy;
end

