#include <stdio.h>

double *map(double (*fce)(double), double *vstup, int pocet){
    int i;
    double *vystup = malloc(pocet*sizeof(double));
    for(i=0;i<pocet; i++)
    {
        vystup[i]=fce(vstup[i]);
    }
    return vystup;
}

double na3(double x)
{
    return x*x*x;
}


int main(int argc, char* argv[])
{
    double pole[5] = {0.1, 0.2, 2, 3, 0.5};
    double *pole_vysledku = map(na3, pole, 5);

    for(int i = 0; i<5; i++)
    {
       printf("%f \n", pole_vysledku[i]);
    }

    free(pole_vysledku);
    return 0;
}
