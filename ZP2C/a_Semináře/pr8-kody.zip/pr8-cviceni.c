#include <stdio.h>

double *map(double (*fce)(double), double *vstup, int pocet){
    int i;
    double *vystup = malloc(pocet*sizeof(double));
    for(i=0;i<pocet; i++)
    {
        vystup[i]=fce(vstup[i]);
    }
    return vystup;
}

double na0(double x)
{
    return 1;
}

double na1(double x)
{
    return x;
}

double na2(double x)
{
    return x*x;
}

double na3(double x)
{
    return x*x*x;
}

double na4(double x)
{
    return x*x*x*x;
}

void vypis_pole(double *pole, int velikost)
{
    for(int i = 0; i<velikost; i++)
    {
       printf("%f, ", pole[i]);
    }
}

double plus(double a, double b)
{
    return a+b;
}

double minus(double a, double b)
{
    return a-b;
}

double krat(double a, double b)
{
    return a*b;
}

double deleno(double a, double b)
{
    if(b!=0)
        return a/b;

    printf("Nelze delit 0\n");
    return 0;
}

int mensi(int a, int b)
{
    if(a<=b)
        return 1;

    return 0;
}

int vetsi(int a, int b)
{
    if(a>=b)
        return 1;

    return 0;
}

void vymena(int *a, int *b)
{
    int pom = *a;
    *a = *b;
    *b = pom;
}

void vypis_pole_int(int *pole, int velikost)
{
    for(int i = 0; i<velikost; i++)
    {
       printf("%i, ", pole[i]);
    }
}

// bubble sort
int* trideni(int (*fce_porovnani)(int,int), void (*fce_vymeny)(int*,int*), int* pole_vstup, int pocet){
    int i, j;
    int *pole = malloc(pocet*sizeof(int));
    memcpy(pole,pole_vstup,pocet*sizeof(int));
    for (i = 0; i < pocet-1; i++)

       // Last i elements are already in place
       for (j = 0; j < pocet-i-1; j++)
           if (!fce_porovnani(pole[j],pole[j+1]))
              fce_vymeny(&pole[j], &pole[j+1]);

    return pole;
}



void cviceni4()
{
    float a,b;
    int operace;
    char op[] = "+-*/";
    double (*pole_aritmetickych_funkci[4])(double,double) = {plus, minus, krat, deleno};
    printf("\nZadejte cislo a: ");
    scanf("%f", &a);
    printf("\nZadejte cislo b: ");
    scanf("%f", &b);
    printf("\nZadejte cislo operace (0 - scitani, 1 - odcitani, 2 - nasobeni, 3 - deleni): ");
    scanf("%i", &operace);

    // zde by se mela udelat kontrola vstupu!

    printf("\n%f %c %f = %f \n", a, op[operace], b, pole_aritmetickych_funkci[operace](a,b));
}

int main(int argc, char* argv[])
{

    /* cviceni 1 */
    printf("Cviceni 1 \n");

    // inicializace
    double (*pole_funkci[5])(double) = {na0, na1, na2, na3, na4};
    // volani
    printf("%f \n", pole_funkci[3](2));


    /* cviceni 2 */
    printf("\nCviceni 2 \n");

    double pole[10] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
    double *pole_vysledku;

    // postupne volani funkci na0, na1, ...
    for(int i=0; i<5; i++)
    {
        pole_vysledku = map(pole_funkci[i], pole, 10);

        // vypsani pole pomoci funkce vypis_pole
        vypis_pole(pole_vysledku,10);
        printf("\n");

        // uvolneni pameti
        free(pole_vysledku);
    }

    /* cviceni 3 */
    printf("\nCviceni 3 \n");

    int pole_hodnot[10] = {1, 20, 30, 10, 2, 6, 4, 8, 7, 10};
    int* vystup;

    // triyeni vzestupne
    vystup = trideni(mensi,vymena,pole_hodnot,10);
    vypis_pole_int(vystup,10);
    free(vystup);

    printf("\n");

    // trizeni sestupne
    vystup = trideni(vetsi,vymena,pole_hodnot,10);
    vypis_pole_int(vystup,10);
    free(vystup);

    /* cviceni 4 */
    printf("\nCviceni 4 \n");

    cviceni4();

    return 0;
}
