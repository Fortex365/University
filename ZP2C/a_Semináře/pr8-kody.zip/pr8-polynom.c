#include <stdio.h>

double polynomA(double x)
{
    return 3*x*x + 2*x +1;
}

double polynomB(double x)
{
    return -3*x*x + 2*x +1;
}

// double (*ptr_polynom)(double) = polynomA;

typedef double (*PTR_POLYNOM)(double);

int main(int argc, char* argv[])
{
    PTR_POLYNOM ptr_polynom = polynomA;
    PTR_POLYNOM ptr_polynom2 = polynomB;

    printf("polynomA: %f \n", ptr_polynom(2));
    printf("polynomB: %f", (*ptr_polynom2)(2));
    return 0;
}
