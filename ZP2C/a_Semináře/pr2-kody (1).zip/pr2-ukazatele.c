#include <stdio.h>

int main()
{
int a = 3, b, *ptr1, *ptr2;

/* ukazatel ptr1 ukazuje na promennou a  */
ptr1 = &a;

/* hodnota b je 5 (*ptr1 je rovna 3) */
b = *ptr1 + 2;

printf("b= %i\n", b);

/* ptr1 a ptr2 ukazuji na stejne misto*/
ptr2 = ptr1;

/* zmenime hodnotu na miste, kam ukazuje ptr2*/
*ptr2 = 5;

printf("a= %i\n", a);

/* hodnota b bude 8*/

b = a + 3;

printf("b= %i\n", b);

// JAK VYPISEME HODNOTU MISTA, KAM UKAZUJE ptr1?

printf("hodnota = %i\n", *ptr1);
printf("adresa a = %p\n", &a);
printf("ptr1 = %p\n", ptr1);
printf("ptr2 = %p\n", ptr2);

return 0;
}
