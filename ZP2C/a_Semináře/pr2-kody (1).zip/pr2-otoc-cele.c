#include <stdio.h>

void otoc_pole(int *p, int velikost)
{
    int i;
    int foo;
    for(i=0; i<velikost/2; i++)
    {
        foo = *(p + i);
        *(p + i) = *(p + velikost - 1 - i);
        *(p + velikost - 1 - i) = foo;
    }
}

void otoc_pole1(int *p, int velikost)
{
    int i;
    int foo;
    for(i=0; i<velikost/2; i++)
    {
        foo = p[i];
        p[i] = p[velikost - 1 - i];
        p[velikost - 1 - i] = foo;
    }
}

int main()
{
int pole[] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
int i=0;

otoc_pole(pole, 10);
//otoc_pole1(pole, 10);

for(i=0; i<10; i++)
{
    printf("%i ", pole[i]);
}

return 0;
}
