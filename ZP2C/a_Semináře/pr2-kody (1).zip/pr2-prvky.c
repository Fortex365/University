#include <stdio.h>

int main()
{
int pole[] = {1, 2, 3};
int i;
for(i = 0; i<3; i++)
{
    printf("%i ",pole[i]);
}
printf("\n");
/* pole[0] = 5 */
*pole = 5;

/* pole[1] = 5 */
*(pole + 1) = 5;

/*  chyba: pole[0] + 1 = 2 */
*pole + 1 = 5;


return 0;
}
