#include <stdio.h>

int main()
{
int pole1[] = {0, 1, 2, 3, 4, 5};
int pole2[] = {1, 2, 3};

/* zde mame informaci o velikosti pole1 */
int size = sizeof(pole1)/sizeof(pole1[0]);

printf("velikost pole1 = %i", size);

/* zde je uz jen ukazatel na prvni prvek */
int *ptr1 = pole1;

/* prirazeni zde nefunguje, pole1 je konstantni pointer */
pole1 = pole2;


return 0;
}
