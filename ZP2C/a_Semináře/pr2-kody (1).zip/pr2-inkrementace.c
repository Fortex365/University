#include <stdio.h>

// Driver program
int main()
{
    int pole[] = {1,2,3,4,5,6,7,8,9,10};
    int *ptr;

    ptr = pole;

    // 1. zpusob
    for (int i = 0; i < 10; i++)
    {
        printf("Hodnota *ptr = %d\n", *(ptr+i));
        printf("Hodnota ptr = %i\n\n", (ptr+i));
    }

    // 2.zpusob
    for (int i = 0; i < 10; i++)
    {
        printf("Hodnota *ptr = %d\n", *ptr);
        printf("Hodnota ptr = %i\n\n", ptr);
        ptr ++;
    }

    return 0;
}
