#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int delka(int p[][10], int cesta[], int pocet)
{
    int r=0;
    int i;

    /*z mista cesta[i-1] do cesta[i] */
    for(i=1;i<pocet;i++)
    {
        int m1 = cesta[i-1];
        int m2 = cesta[i];

        if(p[m1][m2]==-1)
            return -1;

        r+=p[m1][m2];
        // printf("%i ", r);
    }

    return r;
}

int main()
{
    int vzdalenosti[10][10];
    int i,j;

    /* Nahodna inicializace cisly -1 az 10*/
    srand(time(NULL));

    for(i=0;i<10;i++)
        for(j=0;j<10; j++)
            vzdalenosti[i][j] = (rand() % 12)-1;


    /* Vypis vzdalenosti */
    for(i=0;i<10;i++)
    {
        for(j=0;j<10; j++)
        {
            printf("%i ", vzdalenosti[i][j]);
        }
        printf("\n");
    }

    /* Definice cesty */
    int cesta[5]={1,9,8,0,2};

    printf("\n Delka cesty je %i", delka(vzdalenosti, cesta, 5));
}
