#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define VELIKOST_X 10
#define VELIKOST_Y 10


int *ukol2(int m, int n)
{
    int i,j;
    int *pole=malloc((m*n)*sizeof(int));

    for(i=0;i<m;i++)
    {
       for(j=0; j<n;j++)
       {
           pole[i*n + j]=i*j;
       }
    }

    return pole;
}

// m,n reprezentuji velikost pole, znak: 1-krizek, 2-kolecko
void maximum_znaku(int **pole, int m, int n, int znak, int *vysledek)
{
    // v poli vysledek bude ulozena nejvetsi delka na radku, sloupci, dagonalne
    int i,j, ii, jj;
    int maximum = 0;
    int prubezne;


    // radek
    for(i = 0; i<m; i++)
    {
        prubezne = 0;
        for(j=0; j<n; j++)
        {

            if(pole[i][j]==znak)
            {
                prubezne++;
            }
            else
            {
                if(prubezne>maximum)
                {

                    maximum = prubezne;

                }
                prubezne = 0;

            }

        }
        if(prubezne>maximum)
        {

            maximum = prubezne;

        }
    }
    vysledek[0]=maximum;

    maximum=0;

    // sloupec
    for(j = 0; j<n; j++)
    {
        prubezne = 0;
        for(i=0; i<m; i++)
        {
            while(i < m && pole[i][j]==znak)
            {
                prubezne++;
                i++;
            }
            if(prubezne>maximum)
            {
                maximum = prubezne;
            }
            prubezne = 0;
        }
        if(prubezne>maximum)
        {

            maximum = prubezne;

        }
    }
    vysledek[1]=maximum;

    maximum = 0;
    // diagonala
    for(i = 0; i<m; i++)
    {
        prubezne = 0;
        for(j=0; j<n; j++)
        {

            if(pole[i][j]==znak)
            {
                ii = i;
                jj = j;
                //diagonala zleva-dolu
                while(ii<m && jj < n && pole[ii][jj]==znak)
                {
                    prubezne++;
                    ii++;
                    jj++;
                }
                if(prubezne>maximum)
                {

                    maximum = prubezne;

                }
                prubezne = 0;
                //diagonala zleva-nahoru
                ii = i;
                jj = j;
                while(ii>=0 && jj < n && pole[ii][jj]==znak)
                {
                    prubezne++;
                    ii--;
                    jj++;
                }
                if(prubezne>maximum)
                {

                    maximum = prubezne;

                }
                prubezne = 0;

            }
        }
    }
    vysledek[2]=maximum;

}

void vypis_pole(int **pole, int m, int n)
{
    printf("    ");
    for(int j=0; j<n; j++)
    {
            printf("%i ", j);
    }
    printf("\n");
    printf("   ---------------------\n");
    for(int i=0;i<m;i++)
    {
        printf("%i  |", i);
        for(int j=0; j<n; j++)
        {
            switch(pole[i][j])
            {
            case 0:
                printf(" |");
                break;
            case 1:
                printf("X|");
                break;
            case 2:
                printf("O|");
                break;
            }

        }
        printf("\n");
        printf("   ---------------------\n");
    }
}


int **vytvor_pole(int m, int n)
{
    int i,j;
    int **pole2d=malloc(m*sizeof(int*));

    for(i=0;i<m;i++)
    {
       pole2d[i]=malloc(n*sizeof(int));
       for(j=0; j<n;j++)
       {
           pole2d[i][j]=0;
       }
    }

    return pole2d;
}

void uvolni_pole(int **pole, int m)
{
    for(int i; i<m; i++)
    {
        free(pole[i]);
    }
    free(pole);
}

int over_souradnice(int **pole, int x, int y, int m, int n)
{
    // souradnice jsou mimo hraci plochu
    if((x<0) || (x>=m) || (y<0) || (y>=n))
        return 1;

    //pole je obsazeno
    if(pole[x][y]!= 0)
        return 1;

    return 0;
}

int main()
{
    int** hraci_pole = vytvor_pole(VELIKOST_X, VELIKOST_Y);
    int hrac = 1;
    int x, y;
    int *maximum=malloc((3)*sizeof(int));;

    while(1)
    {
        vypis_pole(hraci_pole,VELIKOST_X, VELIKOST_Y);

        printf("Na rade je hrac %i\n", hrac);
        printf("Zadejte souradnice ve tvaru x y: ");
        scanf("%i %i", &x, &y);

        if(over_souradnice(hraci_pole, x, y, VELIKOST_X, VELIKOST_Y))
        {
            printf("Zadane souradnice nejsou spravne. \n");
            continue;
        }

        hraci_pole[x][y]=hrac;

        maximum_znaku(hraci_pole, VELIKOST_X, VELIKOST_Y, hrac, maximum);
        // pouze testovaci vypis
        //printf("radek: %i, sloupec: %i, diagonala: %i\n", maximum[0], maximum[1], maximum[2]);

        if(maximum[0]==5 || maximum[2]==5 || maximum[3]==5) //konec
        {
            printf("Vyhral hrac %i\n", hrac);
            vypis_pole(hraci_pole,VELIKOST_X, VELIKOST_Y);
            break;
        }
        hrac = (hrac==1)? 2 : 1;
    }

    uvolni_pole(hraci_pole, VELIKOST_X);
    free(maximum);

}
