#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int **ukol1(int m, int n)
{
    int i,j;
    int **pole2d=malloc(m*sizeof(int*));

    for(i=0;i<m;i++)
    {
       pole2d[i]=malloc(n*sizeof(int));
       for(j=0; j<n;j++)
       {
           pole2d[i][j]=i*j;
       }
    }

    return pole2d;
}

int *ukol2(int m, int n)
{
    int i,j;
    int *pole=malloc((m*n)*sizeof(int));

    for(i=0;i<m;i++)
    {
       for(j=0; j<n;j++)
       {
           pole[i*n + j]=i*j;
       }
    }

    return pole;
}


void vypis_pole(int **pole, int m, int n)
{
    for(int i=0;i<m;i++)
    {
        for(int j=0; j<n; j++)
        {
            printf("%i ", pole[i][j]);
        }
        printf("\n");
    }
}

void vypis_pole2(int *pole, int m, int n)
{
    for(int i=0;i<m;i++)
    {
        for(int j=0; j<n; j++)
        {
            printf("%i ", pole[i*n + j]);
        }
        printf("\n");
    }
}

int main()
{

    /*
    // ukol 1
    int **vysledek = ukol1(10,10);
    vypis_pole(vysledek, 10, 10);
    for(int i; i<10; i++)
    {
        free(vysledek[i]);
    }
    free(vysledek);
    */

    /*
    // ukol 2
    int *vysledek = ukol2(10,10);
    vypis_pole2(vysledek, 10, 10);
    free(vysledek);
    */


}
