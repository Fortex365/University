#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main()
{
 int *foo;
 int m = 10, i;

 foo = malloc(sizeof(int)*m);
 // inicializace
 for(i=0;i<m;i++)
    foo[i]=i;

for(i=0; i<m;i++)
    printf("%i ",foo[i]);

printf("\n");

/* posun cyklem */

for(i = 1; i < m; i++)
    foo[i-1] = foo[i];


/* kopie pomoci memcpy */
// memcpy(foo,foo+1,sizeof(int)*(m-1));

for(i=0; i<m;i++)
    printf("%i ",foo[i]);

free(foo);

}
