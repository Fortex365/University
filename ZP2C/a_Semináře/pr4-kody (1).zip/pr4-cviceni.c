#include <stdio.h>
#include <string.h>

int velikost(char *r)
{
    int velikost;
    for(velikost=0; r[velikost]; velikost++);

    return velikost;
}


char *uloha1(char *r1, char *r2)
{
    int velikost1, velikost2, vel;
    velikost1 = velikost(r1);
    velikost2 = velikost(r2);

    vel = velikost1 + velikost2;

    char *vysledek = malloc(sizeof(char)*vel);

    memcpy(vysledek,r1,velikost1*sizeof(char));
    memcpy(vysledek+velikost1, r2, velikost2*sizeof(char));

    return vysledek;
}

int *uloha2(int* pole, int velikost)
{
    int *vysledek = malloc(velikost*sizeof(int));

    for(int i = 0; i<velikost; i++)
    {
        vysledek[i]=pole[i]*pole[i];
    }
    return vysledek;
}

void uloha3(int *a, int *b)
{
    int c = *a;

    *a = *b;
    *b = c;
}

float uloha4(float a, float b, int *err) // pokud nelze delit, funkce vraci err = 1
{
    if (b == 0)
    {
        *err = 1;
        return 0;
    }

    *err = 0;
    return a/b;
}

char *uloha5(char *r1, char *r2)
{
    int velikost1 = velikost(r1);
    int velikost2 = velikost(r2);
    int j=0, k;

    printf("%i ",velikost2);

    for(int i=0; i < velikost1-velikost2 +1; i++)
    {
        k = i;
        while(r1[k] == r2[j])
        {
            k++;
            j++;
        }
        if((j-1) == velikost2)
        {
            return &r1[i];
        }
        else
        {
            j = 0;
        }
    }

    return NULL;
}

int uloha6(char *r1, char* r2)
{
    int velikost1 = velikost(r1);
    int velikost2 = velikost(r2);

    if(velikost1 < velikost2)
        return -1;
    if(velikost1 > velikost2)
        return 1;

    for(int i = 0; i<velikost1; i++)
    {
        if(r1[i] < r2[i])
            return -1;
        if(r1[i]>r2[i])
            return 1;
    }

    return 0;
}

int main()
{
    /* // uloha1
    char r1[]="ahoj ";
    char r2[]="svete";

    printf("%s ", uloha1(r1,r2));

    */

    /* // uloha2
    int pole[] = {1, 2, 3, 4};
    int v = 4;
    int *pole2;

    pole2 = uloha2(pole,v);
    for(int i=0; i<v; i++)
    {
        printf("%i ", pole2[i]);
    }
    */

    /* // uloha3
    int a = 3;
    int b = 2;

    printf("a = %i, b = %i\n", a, b);
    uloha3(&a,&b);
    printf("a = %i, b = %i\n", a, b);

    */

    /* // uloha4
    float a = 10.0, b=4, err, vysledek;
    vysledek = uloha4(a,b,&err);
    if(err)
    {
        printf("Nelze spocitat podil");
    }
    else
    {
        printf("Podil je %f", vysledek);
    }
    */

    /* //uloha5
    char r1[] = "ahoj svete";
    char r2[] = "svete";

    char *vysledek;
    vysledek = uloha5(r1, r2);

    if(vysledek)
    {
        printf("adresa prvniho vyskytu je %p\n", vysledek);
        printf("prvni prvek je %c\n", *vysledek);
    }
    else
    {
        printf("retezec nenalezen.");
    }

    */

    /* //uloha5
    char r1[]="ahoj";
    char r2[]="ahoj";

    switch(uloha6(r1,r2))
    {
    case -1:
        printf("retezec 1 je mensi");
        break;
    case 0:
        printf("retezce jsou shodne");
        break;
    case 1:
        printf("retezec 1 je vetsi");
        break;
    }
    */
    return 0;
}
