#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main()
{
 int *foo;
 int m = 10, i;

 foo = malloc(sizeof(int)*m);

 memset(foo,0,sizeof(int)*m);

for(i=0; i<m;i++)
    printf("%i ",foo[i]);


free(foo);

}
