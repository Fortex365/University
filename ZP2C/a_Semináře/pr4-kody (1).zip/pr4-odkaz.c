#include <stdio.h>
#include <stdlib.h>

// navratovy typ funkce: adresa typu int
int deleni(int a, int b, int *r)
{
    /* r - zbytek po deleni */
    *r = a%b;
    return a/b;
}

int main()
{
    int x,y;
    /* x = 2, y = 3*/
    x = deleni(13,5,&y);

    printf("x = %i, y = %i", x, y);
    return 0;
}
