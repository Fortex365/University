#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main()
{
 int *bar;
 int *foo;
 int m = 10;

 bar = calloc(m,sizeof(int));
 foo = malloc(sizeof(int)*m);

/* kopie cyklem */
for(int i = 0; i < m; i = i+1)
    foo[i] = bar[i];

/* kopie pomoci memcpy */
memcpy(foo,bar,sizeof(int)*m);

free(bar);
free(foo);
}
