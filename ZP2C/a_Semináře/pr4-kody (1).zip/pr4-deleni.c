#include <stdio.h>

int deleni(int a, int b,int *r)
{
    *r = a%b;
    return a/b;
}

int main()
{
    int a=13, b=5, r=0;
    int vysledek;

    vysledek = deleni(a,b,&r);

    printf("vysledek= %i\n", vysledek);
    printf("r= %i\n", r);

}
