#include <stdio.h>


int main()
{
    FILE *fr;
    float x,y,z;

    fr = fopen("priklad2.txt", "r");

    fscanf(fr, "%f %f %f", &x, &y, &z);
    printf("%f\n", x+y+z);

    fclose(fr);
    return 0;
}
