#include <stdio.h>

int main()
{
    FILE *fr;
    char c;

    fr = fopen("priklad5a.txt", "r");

    while((c=getc(fr))!='\n')
    {
        printf("%c", c);
    }

    fclose(fr);
    return 0;
}
