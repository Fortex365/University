#include <stdio.h>
#define MAX 5

int main()
{
    FILE *fr;
    char str[MAX];

    fr = fopen("priklad5.txt", "r");

    while(fgets(str,MAX,fr) != NULL)  // overeni konce souboru
    {
        printf("%s\n", str);
    }

    fclose(fr);
    return 0;
}
