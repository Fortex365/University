#include <stdio.h>


int main()
{
    FILE *fr, *fw;
    int c;

    fr = fopen("priklad3.txt", "r");
    fw = fopen("priklad3kopie.txt", "w");

    c = getc(fr);
    while(feof(fr)==0)
    {
        putc(c, fw);
        c = getc(fr);
    }

    fclose(fr);
    fclose(fw);
    return 0;
}
