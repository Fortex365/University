#include <stdio.h>


int main()
{
    FILE *fw;
    int i;

    fw = fopen("priklad1.txt", "w");

    for(i = 1; i<=10; i++)
        fprintf(fw, "%i\n",i);

    fclose(fw);
    return 0;
}
