#include <stdio.h>


int main()
{
    FILE *fr, *fw;
    int c;

    fr = fopen("priklad3.txt", "r");
    fw = fopen("priklad3kopie.txt", "w");

    while((c = getc(fr)) != EOF)
        putc(c, fw);

    fclose(fr);
    fclose(fw);
    return 0;
}
