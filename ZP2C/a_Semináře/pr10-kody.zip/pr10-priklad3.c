#include <stdio.h>


int main()
{
    FILE *fr, *fw;
    int c;

    fr = fopen("priklad3.txt", "r");
    fw = fopen("priklad3kopie.txt", "w");

    // s pomoci promenne c
    c = getc(fr);
    putc(c, fw);

    // primo
    putc(getc(fr), fw);

    fclose(fr);
    fclose(fw);
    return 0;
}
