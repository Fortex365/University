#include <stdio.h>


void uloha1()
{
    FILE *fr, *fw;
    int c;

    if((fr = fopen("priklad3.txt", "r"))==NULL)
    {
        printf("priklad3.txt se nepodarilo otevrit\n");
        return;
    }
    if((fw = fopen("priklad3kopie.txt", "w"))==NULL)
    {
        printf("priklad3kopie.txt se nepodarilo otevrit\n");
        return;
    }

    while((c = getc(fr)) != EOF)
        putc(c, fw);

    if(fclose(fr)== EOF)
    {
        printf("priklad3.txt se nepodarilo zavrit\n");
        return;
    }
    if(fclose(fw)== EOF)
    {
        printf("priklad3kopie.txt se nepodarilo zavrit\n");
        return;
    }
}

void uloha2()
{
    FILE *fr;
    if (fr = fopen("neexistujicisoubor", "r") == NULL)
    {
        printf("neexistujicisoubor se nepodarilo otevrit.\n");
        return;
    }
    fclose(fr);
}

void uloha3()
{
    FILE *fr;
    int pocet = 0;

    fr = fopen("pr10-dopis.txt","r"); // Zde by mel byt test spravnosti otevreni souboru!

    while(getc(fr)!=EOF)
    {
        pocet++;
    }
    fclose(fr); // Opet neni overeni spravnosti zavreni

    printf("V souboru je %i znaku.",pocet);
}

void uloha4()
{
    FILE *fw;
    int i,j;

    fw = fopen("uloha4.txt", "w"); // neni overeni

    for(i = 1; i<=10; i++)
    {
        for(j=1; j<=10; j++)
        {
          fprintf(fw, "%i ",i*j);
        }
        fprintf(fw, "\n");
    }

    fclose(fw); // neni overeni
}

void uloha5()
{
    FILE *fr;
    float soucet=0, cislo;
    int pocet = 0;

    fr = fopen("prumer.txt","r"); // Overeni!

    while(fscanf(fr, "%f", &cislo)==1)
    {
        pocet++;
        soucet = soucet + cislo;
    }

    if(pocet>0)
        printf("Prumer je %f", soucet/pocet);

    fclose(fr); // Overeni!

}

int main()
{
    uloha1();
    // uloha2();
    // uloha3();
    // uloha4();
    // uloha5();
    return 0;
}
