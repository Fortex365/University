#include <stdio.h>
#include <stdlib.h>

int *data;
int velikost;
int hlava;

/*

typedef struct{
    int *data;
    int velikost;
    int hlava;
} POLE;

POLE array;
*/


/* v kodu nahradit
data    za   array.data
velikost     array.velikost
hlava        array.hlava

*/

void init(int v)
{
  data = malloc(sizeof(int)*v);
  hlava = 0;
  velikost = v;
}

void uvolni()
{
    free(data);
}

void vypis()
{
    for(int i = 0; i<hlava; i++)
        printf("%i \n", data[i]);
}

void pridej(int prvek)
{
    if(hlava == velikost)
    {
        data = realloc(data, sizeof(int)*(velikost*2));
        velikost = velikost*2;
    }
    data[hlava]=prvek;
    hlava = hlava + 1;
   // vypis();
}

void odeber_posledni()
{
    hlava = hlava-1;

    // pocet prvku, nemuze byt zaporny
    if(hlava < 0)
        hlava = 0;

    //pripadne zmenseni velikosti pole
    if(hlava < (velikost/2))
    {
        data = realloc(data,sizeof(int)*(velikost/2));
        velikost = velikost/2;
    }


}

void odeber_prvek(int index) //odebere prvek na indexu index
{
        if (index < hlava)
        {
            for(int i=index; i < hlava-1; i++)
            {
                data[i] = data[i+1];
            }
            hlava = hlava-1;
        }

    //pripadne zmenseni velikosti pole
    if(hlava < (velikost/2))
    {
        data = realloc(data,sizeof(int)*(velikost/2));
        velikost = velikost/2;
    }
}

int najdi(int cislo) //vrati index prvku, nebo -1 pokud neni prvek nalezen
{
    for(int i=0; i < hlava; i++)
    {
        if(data[i]==cislo)
        {
            return i;
        }
    }
    return -1;
}

int main()
{
    init(10);

    for(int i=0; i<100; i++)
    {
        pridej(i);
    }
   // vypis();

   // odeber_posledni();
   // vypis();
    odeber_prvek(0);
    vypis();


    uvolni();
    return 0;
}
