#include <stdio.h>
#define POCET_CISEL 10

void uloha2()
{
    FILE *binarni, *textovy;
    int pole[POCET_CISEL];
    binarni = fopen("uloha2bin.txt", "wb");
    textovy = fopen("uloha2text.txt", "wt");

    for(int i = 0; i < POCET_CISEL; i++)
    {
        pole[i] = i;
        putc(i+'0',textovy);
    }

    fwrite(pole, sizeof(int), POCET_CISEL, binarni);

    // posun na konec souboru (je zbytecne, pro zapisu je na konci)
    fseek(binarni, 0L, SEEK_END);
    fseek(textovy, 0L, SEEK_END);


    // %lu  znaci, ze vystupem bude unsigned long cislo
    printf("Velikost binarniho souboru je %lu bytu.\n", ftell(binarni));
    printf("Velikost textoveho souboru je %lu bytu.\n", ftell(textovy));

    fclose(binarni);
    fclose(textovy);
}

void uloha3()
{
    FILE *binarni, *textovy;
    int cislo = 1234567;
    char textcislo[]="1234567";
    binarni = fopen("uloha3bin.txt", "wb");
    textovy = fopen("uloha3text.txt", "wt");

    fwrite(&cislo, sizeof(int), 1, binarni);
    fputs(textcislo, textovy);

    // posun na konec souboru (je zbytecne, pro zapisu je na konci)
    fseek(binarni, 0L, SEEK_END);
    fseek(textovy, 0L, SEEK_END);


    // %lu  znaci, ze vystupem bude unsigned long cislo
    printf("Velikost binarniho souboru je %lu bytu.\n", ftell(binarni));
    printf("Velikost textoveho souboru je %lu bytu.\n", ftell(textovy));

    fclose(binarni);
    fclose(textovy);
}

void uloha4()
{
    float pole[5] = {1.2, 2.2, 3.1, 0.0, 1.0};
    FILE *fw;

    fw = fopen("uloha4.txt", "wb");
    fwrite(pole, sizeof(float), 5, fw);


    fclose(fw);
}

void uloha5()
{
    FILE *fr;
    float soucet = 0, ctene;
    int pocet = 0;

    fr = fopen("uloha4.txt", "rb");

    while(fread(&ctene, sizeof(float), 1, fr))
    {
        soucet = soucet + ctene;
        pocet++;
    }
    printf("Prectenych cisel je: %i \n Jejich prumer je: %f", pocet, soucet/pocet);

    fclose(fr);
}

int main(void)
{
    //uloha2();
    //uloha3();
    //uloha4();
    uloha5();
    return 0;
}
