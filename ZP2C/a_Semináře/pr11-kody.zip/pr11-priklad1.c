#include <stdio.h>

int main(void)
{
    FILE *soubor;
    size_t i;
    char pole[100];
    soubor = fopen("priklad1.txt", "fb");

    // posun na konec souboru
    fseek(soubor, 0L, SEEK_END);

    // %lu  znaci, ze vystupem bude unsigned long cislo
    printf("Velikost souboru je %lu bytu.\n", ftell(soubor));

    fclose(soubor);
    return 0;
}
