#include <stdio.h>
#include <stdlib.h>

/* definice seznamu*/
typedef struct _node{
    int data;
    struct _node *next;
} node;

node *add(node **list, int data)
{
    node *new = malloc(sizeof(node));
    new->data = data;
    new->next = *list;
    *list = new;
    return new;
}

void print_nodes(node *list)
{
    while(list){
        printf("%i ", list->data);
        list = list->next;
    }
    printf("\n");
}


int list_length(node *list)
{
    int delka=0;
    while(list){
        delka++;
        list = list->next;
    }
    return delka;
}

void add_last(node *list, int data)
{
    node *new = malloc(sizeof(node));
    new->data = data;
    new->next = 0;
    while(list){
        if(list->next == 0)
        {
            list->next = new;
            break;
        }
        list = list->next;
    }

}

void remove_first(node **list)
{
    node* first = *list; // zapamatovani prvniho prvku pro uvolneni pameti

    *list = (*list)->next;

    free(first);
}

void remove_last(node *list)
{
    int delka = list_length(list);

    for(int i = 1; i<delka-1; i++)
        list = list->next;

    free(list->next);
    list->next = 0;

}

int return_i(node *list, int i)
{
    for(int j=1; j<i; j++)
        list = list->next;

    return list->data;
}

int return_last_i(node *list, int i)
{
    int delka = list_length(list);
    for(int j=0; j<delka-i; j++)
        list = list->next;


    return list->data;
}

node* copy_list(node *list)
{
    node *new = malloc(sizeof(node));
    new->data = list->data;
    new->next=0;
    if(list->next)
    {
        list=list->next;
        while(list){
            add_last(new, list->data);
            list = list->next;
        }
    }
    return new;
}

void remove_i(node *list, int i)
{
    for(int j=1; j<i-1; j++)
        list = list->next;

    node* pomocny = list->next;
    list->next = (list->next)->next;
    free(pomocny);
}

int main()
{
    /* Test */
    node *list = 0;
    int i;

    for(i=0; i<10; i++)
        add(&list, i);

    /* POZOR! V zadne z funkci nedelam kontrolu spravnosti vstupu! Spravne by tam byt mela. */

    // vypis seznamu
    print_nodes(list);

    // delka seznamu
    printf("delka: %i \n", list_length(list));

    // pridani prvku na konec
    printf("Pridani prvku na konec \n");
    add_last(list, 5);
    print_nodes(list);

    // smazani prvniho prvku
    printf("Smazani prvniho prvku \n");
    remove_first(&list);
    print_nodes(list);

    // smazani posledniho prvku
    printf("Smazani posledniho prvku \n");
    remove_last(list);
    print_nodes(list);

    // vrazecni i teho prvku (indexovane od 1)
    i = 4;
    printf("%i prvek: %i \n", i, return_i(list,i));

    // vrazecni i teho prvku od konce
    i = 4;
    printf("%i prvek od konce: %i \n", i, return_last_i(list,i));

    // smazani i teho prvku
    i = 4;
    printf("Smazani %i teho prvku \n", i);
    remove_i(list,i);
    print_nodes(list);


    // kopie seznamu
    node *kopie;

    printf("Kopie \n");
    kopie = copy_list(list);
    print_nodes(list);
    print_nodes(kopie);
    // zmena originalu
    add(&list, 10);
    print_nodes(list);
    print_nodes(kopie);
}
