﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zp3cs_4_tridy_1
{
    class Class2
    {
    }
}
