﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Netreba_Ukol7
{
    interface ICompare //IPorovnani
    {
        void largerVolume(object c); //vetsiObsah
        void largerPerimeter(object c); //vetsiObvod
    }
}
