﻿using System;
using Extensions;

namespace ExtensionMethod
{
    class Program
    {
        

        static void Main()
        {
            try
            {
                
            }
            catch (Exception ex)
            {
                Console.WriteLine("Výjimka: {0}", ex.Message);
            }
        }
    }
}
