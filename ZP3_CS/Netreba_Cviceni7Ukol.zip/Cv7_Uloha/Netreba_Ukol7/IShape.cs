﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Netreba_Ukol7
{
    interface IShape //ITvar
    {
        double Volume(); //Obsah
        double Perimeter(); //Obvod
    }
}
