#include <stdio.h>

int main()
{
    int n, n1;
    printf("Zadejte hodnotu n: ");
    scanf("%i", &n);
    printf("Zadejte hodnotu n: ");
    scanf("%i", &n1);

    if (n = 3)
    {
        if (n1 = 3)
        {
            printf("\n*");
            printf("\n* * * ");
            printf("\n* * * * * ");
        }
        if (n1 = 4)
        {
            printf("\n*");
            printf("\n* * * ");
            printf("\n* * * * * ");
            printf("\n* * * * * * ");
        }
    }
    if (n = 2)
    {
        if (n1 = 2)
        {
            printf("\n* ");
            printf("\n* * * ");
            printf("\n* ");
        }
        if (n1 = 3)
        {
            printf("\n* ");
            printf("\n* * * ");
            printf("\n* * * * * *");
            printf("\n* * * ");
            printf("\n* ");
        }
    }
    if (n = 4)
    {
        printf(" * *");
        printf("* * ");
        printf(" * *");
        printf("* * ");
    }
return 0;
}
