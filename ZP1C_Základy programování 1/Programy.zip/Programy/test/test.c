#include <stdio.h>

int main()
{
    char pole[50];
    int ir = 5, i;

    for(i = 0;i < 100;i++)
    {
        if(i=10)
        {
            pole[i] = ir;
        }
    }
    printf("%c",pole[10]);
    return 0;
}
