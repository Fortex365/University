#include <stdio.h>
#include <conio.h>

int main()
{
    char n = 'Slovo';
    printf("%c", n);
    return 0;
}
