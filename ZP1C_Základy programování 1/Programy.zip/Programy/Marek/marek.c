#include <stdio.h>
int main()
{
    int pole[] = '"';
    printf("%c", pole[1]);
}
