﻿using System;

namespace XML_JSON
{
    class Student
    {
        public short StudyYear;
        public string Name;
        public string Surname;
    }
}
